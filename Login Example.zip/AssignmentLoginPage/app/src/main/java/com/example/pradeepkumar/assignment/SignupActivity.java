package com.example.pradeepkumar.assignment;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class SignupActivity extends AppCompatActivity {
    private EditText email, password, username;
    private TextView login_msg, signup, login;
    private MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        myAdapter = new MyAdapter(this);
        myAdapter = myAdapter.open();

        login = (TextView) findViewById(R.id.login);
        signup = (TextView) findViewById(R.id.user_signup);
        login_msg = (TextView) findViewById(R.id.user_login);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        email = (EditText) findViewById(R.id.email_add);

        //Logging text click listener
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(SignupActivity.this, MainActivity.class);
                startActivity(it);
            }
        });

        /*Signup Onclick listener*/
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*Values*/
               String myUsername = username.getText().toString();
               String myPassword = password.getText().toString();
               String myEmail = email.getText().toString();



                if(myUsername.equals("")||myPassword.equals("")||myEmail.equals(""))
                {
                    Toast.makeText(getApplicationContext(), "Field Vaccant", Toast.LENGTH_LONG).show();
                    return;
                }
                else
                {
                    myAdapter.insertEntry(myUsername, myEmail, myPassword);

                    AlertDialog.Builder builder = new AlertDialog.Builder(SignupActivity.this);
                    builder.setCancelable(false);
                    builder.setTitle("Email Varification");
                    builder.setMessage("Your varification code has been sent to this Email");
                    builder.setPositiveButton("OK!!!", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(getApplicationContext(), "Account Successfully Created ", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(SignupActivity.this, OtherActivity.class);
                            intent.putExtra("Value", username.getText().toString());
                            startActivity(intent);
                        }
                    })
                            .setNegativeButton("Cancel ", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Toast.makeText(getApplicationContext(), "Account Successfully Created ", Toast.LENGTH_LONG).show();
                                    finish();
                                }
                            });
                    builder.create().show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();

        myAdapter.close();
    }
}