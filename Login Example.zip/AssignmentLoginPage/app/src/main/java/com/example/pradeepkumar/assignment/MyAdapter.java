package com.example.pradeepkumar.assignment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by PRADEEP KUMAR on 29-01-2018.
 */

public class MyAdapter {
    static final String DATABASE_NAME = "login.db";
    static final int DATABASE_VERSION = 1;
// for creating table
    static final String DATABASE_CREATE = "create table "+"LOGIN"+
            "( " +"ID"+" integer primary key autoincrement,"+ "USERNAME  text, EMAIL text, PASSWORD text); ";

    public  SQLiteDatabase db;

    private final Context context;

    private DBHelper dbHelper;
    public  MyAdapter(Context _context)
    {
        context = _context;
        dbHelper = new DBHelper(context, DATABASE_NAME	, null, DATABASE_VERSION);
    }
    public  MyAdapter open() throws SQLException
    {
        db = dbHelper.getWritableDatabase();
        return this;
    }
    public void close()
    {
        db.close();
    }

    public  SQLiteDatabase getDatabaseInstance()
    {
        return db;
    }

// for inserting Data
    public void insertEntry(String userName, String email, String password)
    {
        ContentValues newValues = new ContentValues();
        newValues.put("EMAIL",email);
        newValues.put("USERNAME", userName);
        newValues.put("PASSWORD",password);


        db.insert("LOGIN", null, newValues);

    }
    // for deleting Data
    public int deleteEntry(String UserName)
    {

        String where="USERNAME=?";
        int numberOFEntriesDeleted= db.delete("LOGIN", where, new String[]{UserName}) ;

        return numberOFEntriesDeleted;
    }
    //  for finding data
    public String getSinlgeEntry(String userName)
    {
        Cursor cursor=db.query("LOGIN", null, " USERNAME=?", new String[]{userName}, null, null, null);
        if(cursor.getCount()<1)
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String password= cursor.getString(cursor.getColumnIndex("PASSWORD"));
        cursor.close();
        return password;

    }
    // for updating data
    public void  updateEntry(String userName, String password)
    {

        ContentValues updatedValues = new ContentValues();

        updatedValues.put("USERNAME", userName);
        updatedValues.put("PASSWORD",password);

        String where="USERNAME = ?";
        db.update("LOGIN",updatedValues, where, new String[]{userName});
    }
}
