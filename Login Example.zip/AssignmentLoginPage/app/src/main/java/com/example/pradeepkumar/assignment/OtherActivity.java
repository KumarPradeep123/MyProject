package com.example.pradeepkumar.assignment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class OtherActivity extends AppCompatActivity {
TextView user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other);
        user=(TextView)findViewById(R.id.user);
        String value=getIntent().getExtras().getString("Value");
        user.setText("Hello " + value);
    }

}
