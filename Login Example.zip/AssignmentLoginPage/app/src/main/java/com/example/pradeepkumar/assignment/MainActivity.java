package com.example.pradeepkumar.assignment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
/**
 * Created by PRADEEP KUMAR on 29-01-2018.
 */

public class MainActivity extends AppCompatActivity {
    private EditText password, username;
    private TextView signup;
    private MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myAdapter = new MyAdapter(this);
        myAdapter = myAdapter.open();

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        signup = (TextView) findViewById(R.id.signup);


        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });

    }
// for login
    public void userLogin(View view) {
        String myUsername = username.getText().toString();
        String myPassword = password.getText().toString();
        String storedPassword = myAdapter.getSinlgeEntry(myUsername);


        if (myPassword.equals(storedPassword)) {
            Toast.makeText(MainActivity.this, "Congrats: Login Successfull", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(MainActivity.this, OtherActivity.class);
            intent.putExtra("Value", myUsername);
            startActivity(intent);
        } else {
            Toast.makeText(MainActivity.this, "User Name or Password does not match", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        myAdapter.close();
    }
}





