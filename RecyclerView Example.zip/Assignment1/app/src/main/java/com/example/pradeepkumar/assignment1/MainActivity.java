package com.example.pradeepkumar.assignment1;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
EditText rollno, name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rollno=(EditText)findViewById(R.id.txtrollno);
        name=(EditText)findViewById(R.id.txtname);
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase database = helper.getWritableDatabase();
            database.execSQL("create table Student(rollNo integer primary key,name text)");
        }catch (Exception ex)
        {
            System.out.println(ex);
        }
    }
    public void Insert(View view){
        DBHelper helper = new DBHelper(this);
        SQLiteDatabase database = helper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("rollNo" , rollno.getText().toString());
        database.insert("Student",null,values);
    }
        public void Next(View view){
            Intent intent=new Intent(this,RecyclerView.class);
            startActivity(intent);
        }
}
