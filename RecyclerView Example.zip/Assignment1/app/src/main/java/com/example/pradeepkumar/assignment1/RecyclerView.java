package com.example.pradeepkumar.assignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;

public class RecyclerView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);
        android.support.v7.widget.RecyclerView programmingList=(android.support.v7.widget.RecyclerView)findViewById(R.id.programmingList);
        programmingList.setLayoutManager(new LinearLayoutManager(this));
        String[] myfriendList={"Pradhan","Rahul","vikas","Kushagra","Nitin","Raju","Swetank","Rakesh","Golu","Ritesh","Rishabh","Yash","Krishna","Srinath"};
        programmingList.setAdapter(new Adapter(myfriendList));
    }

}
