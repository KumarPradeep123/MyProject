package com.example.pradeepkumar.assignment1;

/**
 * Created by PRADEEP KUMAR on 17-01-2018.
 */

public class Data {
    private String rollNo,name;

    public Data(String rollNo, String name) {
        this.rollNo = rollNo;
        this.name = name;
    }
    public String getRollNo() {
        return rollNo;
    }

    public String getName() {
        return name;
    }
}
