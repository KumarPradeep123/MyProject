package com.example.pradeepkumar.rockpaperscissor;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView img1, img2;
    Button rock, paper, scissors;
    String myChoice, cpuChoice, result;
    Random r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img1 = (ImageView) findViewById(R.id.imageView);
        img2 = (ImageView) findViewById(R.id.imageView2);
        rock = (Button) findViewById(R.id.rock);
        paper = (Button) findViewById(R.id.paper);
        scissors = (Button) findViewById(R.id.scissors);
        r = new Random();
    }

    public void rock(View view) {
        myChoice = "rock";
        img2.setImageResource(R.drawable.a);
        calculate();

    }

    public void paper(View view) {
        myChoice = "paper";
        img2.setImageResource(R.drawable.b);
        calculate();
    }

    public void scissors(View view) {
        myChoice = "scissors";
        img2.setImageResource(R.drawable.c);
        calculate();
    }

    public void calculate() {
        int cpu = r.nextInt(3);
        if (cpu == 0) {
            cpuChoice = "rock";
            img1.setImageResource(R.drawable.a);
        } else if (cpu == 1) {
            cpuChoice = "paper";
            img1.setImageResource(R.drawable.b);
        } else if (cpu == 2) {
            cpuChoice = "scissors ";
            img1.setImageResource(R.drawable.c);
        }
        if(myChoice.equals("rock")&& cpuChoice.equals("paper")){
            result="You lose";
        }else
        if(myChoice.equals("rock")&& cpuChoice.equals("scissors")){
            result="You win";
        }else
        if(myChoice.equals("paper")&& cpuChoice.equals("rock")){
            result="You win";
        }else
        if(myChoice.equals("paper")&& cpuChoice.equals("scissors")){
            result="You lose";
        }else
        if(myChoice.equals("scissors")&& cpuChoice.equals("paper")){
            result="You win";
        }else
        if(myChoice.equals("scissors")&& cpuChoice.equals("rock")){
            result="You lose";
        }else
        if(myChoice.equals("rock")&& cpuChoice.equals("rock")) {
            result = "Draw";
        }else
        if(myChoice.equals("scissors")&& cpuChoice.equals("scissors")) {
            result = "Draw";
        }else
        if(myChoice.equals("paper")&& cpuChoice.equals("paper")) {
            result = "Draw";
        }
        Toast.makeText(this, result,Toast.LENGTH_SHORT).show();

    }
}