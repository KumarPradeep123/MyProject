package com.example.pradeepkumar.accountsummary;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Calendar;

public class Account extends AppCompatActivity {
    EditText name, number, amount, other, search;
    private int year, month, day;
    Button BtnDate;
    Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        name = (EditText) findViewById(R.id.pName);
        number = (EditText) findViewById(R.id.pNumber);
        amount = (EditText) findViewById(R.id.pAmnt);
        other = (EditText) findViewById(R.id.txtTo);
        search = (EditText) findViewById(R.id.txtSearch);
        BtnDate = (Button) findViewById(R.id.btnDate);
        try{
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            db.execSQL("create table account(srno integer primary key autoincrement, name text, number text, amount text, other text, day integer, month integer, year integer)");
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    public void Deposit(View view) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("name", "" + name.getText());
            values.put("number","" + number.getText());
            values.put("amount","" + amount.getText());
            values.put("other","" + other.getText());
            values.put("day", day);
            values.put("month", month);
            values.put("year", year);
            db.insert("account", null, values);
            Toast.makeText(this, "Data inserted successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void Search(View view) {
           try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getReadableDatabase();
            String Search = search.getText().toString();
            String column[] = {"name", "number", "amount", "other", "day", "month", "year"};
            String para[] = {Search};
            Cursor cursor = db.query("account", column, "name=?", para, null, null, null, null);
            if (cursor.moveToFirst()) {
                name.setText("" + cursor.getString(0));
                number.setText("" + cursor.getString(1));
                amount.setText("" + cursor.getString(2));
                other.setText("" + cursor.getString(3));
                BtnDate.setText(cursor.getString(4) + "/" + cursor.getString(5) + "/" + cursor.getString(6));
                return;
            } else {
                number.setText("Not found");
                name.setText("Not found");
                amount.setText("Not found");
                other.setText("Not found");
                BtnDate.setText("Not found");
            }
            Toast.makeText(this, "Data searched successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void Delete(View view) {

       try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            String[] para = {"" + name.getText()};
            db.delete("account", "name=?", para);
            Toast.makeText(this, "Data deleted successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    public void Update(View view){
       try{
        DBHelper helper = new DBHelper(this);
        SQLiteDatabase db = helper.getWritableDatabase();
        String Name = name.getText().toString();
        String Number = number.getText().toString();
        String Amount = amount.getText().toString();
        String Other = other.getText().toString();
        ContentValues values = new ContentValues();
        values.put("name", Name);
        values.put("number", Number);
        values.put("amount", Amount);
        values.put("other", Other);
        values.put("day", day);
        values.put("month", month);
        values.put("year", year);
        String []para={Name};
        db.update("account", values,"name=?", para);
        Toast.makeText(this, "Data updated successfully", Toast.LENGTH_SHORT).show();
    } catch (Exception ex) {
        System.out.println(ex.getMessage());
    }
    }
    public void Date(View view) {
        try {
            new DatePickerDialog(this, date, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        } catch (Exception ex) {
            ex.getMessage();
        }
    }

    DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
            day = datePicker.getDayOfMonth();
            month = datePicker.getMonth() + 1;
            year = datePicker.getYear();
            BtnDate.setText(day + "/" + month + "/" + year);
        }
    };
}
