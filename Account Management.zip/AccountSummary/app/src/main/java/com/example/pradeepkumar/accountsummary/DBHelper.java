package com.example.pradeepkumar.accountsummary;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PRADEEP KUMAR on 03-01-2018.
 */

public class DBHelper extends SQLiteOpenHelper {
Context context;

    public DBHelper(Context context) {
        super(context, "account.db", null, 1);
        this.context=context;}
    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}

