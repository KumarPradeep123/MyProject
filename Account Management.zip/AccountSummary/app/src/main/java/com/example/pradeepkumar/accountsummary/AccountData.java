package com.example.pradeepkumar.accountsummary;

/**
 * Created by PRADEEP KUMAR on 04-01-2018.
 */

public class AccountData {
    String srno;
    String number;
    String name;
    String amount;
    String other;
    String day;
    String month;
    String year;

    public AccountData(String srno, String number, String name, String amount, String other, String day, String month, String year) {
        this.srno = srno;
        this.number = number;
        this.name = name;
        this.amount = amount;
        this.other = other;
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public String getSrno() {return srno;}

    public String getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public String getAmount() {
        return amount;
    }

    public String getOther() {
        return other;
    }

    public String getDay() {
        return day;
    }

    public String getMonth() {
        return month;
    }

    public String getYear() {
        return year;
    }
}
