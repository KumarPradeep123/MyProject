package com.example.pradeepkumar.internshipproject;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<MyData> ItemList = new ArrayList<>();
    private RecyclerView recyclerView;
    private MyAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        mAdapter = new MyAdapter(ItemList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        prepareMovieData();
    }

    private void prepareMovieData() {
        MyData item = new MyData("Vangipurapu Venkata Sai Laxman", "Cricketer, Batsman", "https:\\/\\/qph.ec.quoracdn.net\\/main-qimg-4f5029c4319b41270f5643d461979645-c");
        ItemList.add(item);

        item = new MyData("Himesh Reshammiya", "music director, singer, producer, lyricist, distributor and actor", "https:\\/\\/starsunfolded-1ygkv60km.netdna-ssl.com\\/wp-content\\/uploads\\/2016\\/01\\/Himesh-Reshammiya-nasal-singing.jpg");
        ItemList.add(item);

        item = new MyData("Rajkummar Rao", "Indian actor", "https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn:ANd9GcQhShfz5g33MOXBKtLlEXo16uuxEpHFL8NYQE2lg071avavYeKr");
        ItemList.add(item);

        item = new MyData("Pusarla Venkata Sindhu", "badminton player", "https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn:ANd9GcTC0wYTxk72MNx5IADgDDMAqUz9AEyfR6UZexWNqn_fKFNZCLz-");
        ItemList.add(item);

        item = new MyData("Venkatanarasimha Rajuvaripet", "UI\\/UX, iOS, Swift - 3.0, Objective-C, iPhone, iPad, Mac OS, Java, J2EE, PHP, HTML\\/CSS, JavaScript, AngularJS, Node.js, Ruby, Python, Databases & Web Storage, HTTP & REST, Web Application Architecture, Basic Algorithms & Data Structures, Git version control system, ", "https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn:ANd9GcRuFl9rvDAx18eiolXc9FG5kt6Jn3RCqDhsez5nz-JS2tNK53YGEg");
        ItemList.add(item);

        item = new MyData("Abhinav Bindra", "Indian businessman and retired professional shooter", "https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn:ANd9GcT6zeqq8v3upCpuFgSR6YHVhZ_Dja6uc7FAjdyq5Z6BnxczzCV_");
        ItemList.add(item);

        item = new MyData("Raghuram Rajan", "Economist", "https:\\/\\/teekhapan.files.wordpress.com\\/2012\\/08\\/raghuram-rajan.jpg?w=229&h=300");
        ItemList.add(item);

        item = new MyData("Kumar", "builder", "https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn:ANd9GcRKJk2hWltaMgJcf3QO6jIXOhmravSvIqEWAl9stEfszcjLNMVzPg");
        ItemList.add(item);

        item = new MyData("Ranjit", "builder", "https:\\/\\/is1-2.housingcdn.com\\/4f2250e8\\/ee8bf39d2001fde419f82e0e6e90fb59\\/v5\\/_logo\\/solitare_ranjit_avenue1_bulara-ludhiana-solitare_colonizersand_builders.jpg");
        ItemList.add(item);

        item = new MyData("A. R. Rahman", "Indian composer", "https:\\/\\/encrypted-tbn0.gstatic.com\\/images?q=tbn:ANd9GcSGYj7eiL5RBu7n3fq8MD9iSrFq6p1IQ9t1_YacHM345SItjVOX");
        ItemList.add(item);

        item = new MyData("Gauri lankesh", "jouRNAList, activIST", "");
        ItemList.add(item);

        item = new MyData("Nalini", "Fashion Designer", "");
        ItemList.add(item);

        item = new MyData("Gauri", "RJ", "");
        ItemList.add(item);

        item = new MyData("kanika", "singer, musician", "");
        ItemList.add(item);

        item = new MyData("Akshay Kumar", "Actor", "");
        ItemList.add(item);

        mAdapter.notifyDataSetChanged();
    }
}