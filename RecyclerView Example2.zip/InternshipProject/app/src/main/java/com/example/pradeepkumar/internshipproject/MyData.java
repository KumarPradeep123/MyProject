package com.example.pradeepkumar.internshipproject;

/**
 * Created by PRADEEP KUMAR on 10-02-2018.
 */

public class MyData {
    private String name;
    private String skill;
    private String imageUrl;

    public MyData(String name, String skill, String imageUrl) {
        this.name = name;
        this.skill = skill;
        this.imageUrl = imageUrl;
    }
    public String getName() {
        return name;
    }

    public String getSkill() {
        return skill;
    }

    public String getImageUrl() { return imageUrl; }

    public void setName(String name) {
        this.name = name;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
