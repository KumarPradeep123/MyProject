package com.example.pradeepkumar.projectassignment;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by PRADEEP KUMAR on 09-02-2018.
 */

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private List<MyData> myData;
    private Context context;

    public MyAdapter(List<MyData> myData, Context context) {
        this.myData = myData;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
        return new ViewHolder(view, context, myData);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        MyData listItem = myData.get(position);

        holder.textRank.setText("Rank: " + listItem.getRank());
        holder.textCountry.setText(listItem.getCountry());
        holder.textPapulation.setText("Papulation: " + listItem.getPopulation());
        Picasso.with(context).load(listItem.getFlag()).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return myData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView textRank, textCountry, textPapulation;
        public ImageView imageView;
        private List<MyData> myData;
        private Context context;


        public ViewHolder(View itemView, Context context, List<MyData> myData ) {
            super(itemView);
            this.myData = myData;
            this.context = context;
            itemView.setOnClickListener(this);
            textRank = (TextView) itemView.findViewById(R.id.txtRank);
            textCountry = (TextView) itemView.findViewById(R.id.txtCountry);
            textPapulation = (TextView) itemView.findViewById(R.id.txtPapulation);
            imageView = (ImageView) itemView.findViewById(R.id.flag);

        }

        @Override
        public void onClick(View view) {
            int position = getAdapterPosition();
            MyData data = this.myData.get(position);
            Intent intent = new Intent(this.context, Detail.class);
            intent.putExtra("country", data.getCountry());
            intent.putExtra("rank", data.getRank());
            intent.putExtra("population", data.getPopulation());
            intent.putExtra("flag", data.getFlag());
            this.context.startActivity(intent);

        }
    }
}
