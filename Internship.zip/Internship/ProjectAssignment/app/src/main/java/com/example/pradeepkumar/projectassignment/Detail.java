package com.example.pradeepkumar.projectassignment;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.squareup.picasso.Picasso;

public class Detail extends AppCompatActivity {
    ImageView imageView;
    TextView country, rank, population;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent intent = getIntent();
        String imageUrl = intent.getStringExtra("flag");
        String mRank = intent.getStringExtra("rank");
        String mCountry = intent.getStringExtra("country");
        String mPopulation = intent.getStringExtra("population");

        imageView = (ImageView)findViewById(R.id.detailPic);
        country = (TextView)findViewById(R.id.countryText);
        rank = (TextView)findViewById(R.id.rankText);
        population = (TextView)findViewById(R.id.populationText);

        country.setText(mCountry);
        rank.setText("Rank: " + mRank);
        population.setText("Population: " + mPopulation);
        Picasso.with(this).load(imageUrl).into(imageView);


    }
}
