package com.example.pradeepkumar.coinflip;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    TextView txt1, txt2;
    ImageView img1, img2, img3;
    Random r;
    int coinSide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img1=(ImageView)findViewById(R.id.imageView);
        img2=(ImageView)findViewById(R.id.imageView2);
        img3=(ImageView)findViewById(R.id.imageView3);
        r= new Random();
        txt1=(TextView)findViewById(R.id.textView);
        txt2=(TextView)findViewById(R.id.textView2);
    }
    public  void Toss(View view){
        coinSide=r.nextInt(2);
        if(coinSide==0) {
            Toast.makeText(this,"Head!",Toast.LENGTH_SHORT).show();
            img1.setImageResource(R.drawable.head);
            img2.setImageResource(R.drawable.win);
            img3.setImageResource(0);
            txt1.setText("You won");
            txt2.setText("");
        }else if(coinSide==1){
            Toast.makeText(this,"Tail!",Toast.LENGTH_SHORT).show();
            img1.setImageResource(R.drawable.back);
            img2.setImageResource(0);
            img3.setImageResource(R.drawable.loss);
            txt2.setText("You loss");
            txt1.setText("");
        }
        RotateAnimation rotateAnimation=new RotateAnimation(0, 360, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f);
       rotateAnimation.setDuration(800);
       img1.startAnimation(rotateAnimation);
    }
    public void Reset(View view){
        txt1.setText("");
        txt2.setText("");
        img1.setImageResource(R.drawable.front);
        img3.setImageResource(0);
        img2.setImageResource(0);

    }
    }

